
import entidade.*;
public class crud {

    public void cadastrarCliente(cliente cliente) {
        String sql = "INSERT INTO cliente (id_cliente, nome_cliente, numero ) VALUES (?,?,?)";

        connection conexao = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = Conexao.createConnectionMYSQL();
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, cliente.getId_cliente());
            preparedStatement.setString(2, cliente.getNome_cliente());
            preparedStatement.setInt(3, cliente.getNumero());

            preparedStatement.execute();

            System.out.println("CLIENTE CADASTRADO COM SUCESSO");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }
}
