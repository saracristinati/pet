package entidade;

import java.sql.Date;

public class servicos {

    private int id_servicos;
    private String descricao;
    private Date data_servico;
    private double valor;

public servicos(){

}

public servicos(int id_servicos, String descricao, Date data_servico, double valor){
    this.id_servicos = id_servicos;
    this.descricao = descricao;
    this.data_servico = data_servico;
    this.valor = valor;
}

    public int getId_servicos() {
        return id_servicos;
    }

    public void setId_servicos(int id_servicos) {
        this.id_servicos = id_servicos;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Date getData_servico() {
        return data_servico;
    }

    public void setData_servico(Date data_servico) {
        this.data_servico = data_servico;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
}
