package entidade;

public class cliente {

    private int id_cliente;
    private String nome_cliente;
    private  int numero;

    public cliente (){

    }

    public cliente (int id_cliente, String nome_cliente, int numero){
    this.id_cliente = id_cliente;
    this.nome_cliente = nome_cliente;
    this.numero = numero;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getNome_cliente() {
        return nome_cliente;
    }

    public void setNome_cliente(String nome_cliente) {
        this.nome_cliente = nome_cliente;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
}
